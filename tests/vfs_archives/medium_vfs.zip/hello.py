#!/usr/bin/env python3
print('Hello from VFS!')
